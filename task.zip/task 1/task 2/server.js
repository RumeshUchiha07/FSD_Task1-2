/* it is nessery to install the express pakage using the following comment 
npm install express
in theriminal of ur theriminal  to run this code */

const express = require('express');
const app = express();
const port = 3000;

app.get('/home', (req, res) => {
  res.send('Welcome to the Home Page!');
});

app.get('/about', (req, res) => {
  res.send('This is the About Page.');
});

app.get('/contact', (req, res) => {
  res.send('Contact us at contact@example.com.');
});

app.get('/greet', (req, res) => {
  const name = req.query.name || 'Rumesh';
  res.send(`Hello, ${name}!`);
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

// use the link http://localhost:3000/home ,http://localhost:3000/about ,http://localhost:3000/contact to display all the messages
